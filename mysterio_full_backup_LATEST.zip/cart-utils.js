function getCart() {
  try {
    return JSON.parse(localStorage.getItem("mysterio_cart") || "[]");
  } catch (e) {
    return [];
  }
}

function setCart(cart) {
  localStorage.setItem("mysterio_cart", JSON.stringify(cart));
  updateCartBadge();
}

function addToCartStorage(item) {
  const cart = getCart();
  const existing = cart.find(i => i.productId === item.productId && i.variantId === item.variantId);
  if (existing) {
    existing.quantity = (existing.quantity || 1) + (item.quantity || 1);
  } else {
    cart.push(item);
  }
  setCart(cart);
}

function updateCartBadge() {
  const cart = getCart();
  const totalCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  document.querySelectorAll("[data-cart-count]").forEach(badge => {
    badge.textContent = totalCount;
    badge.style.display = totalCount > 0 ? "flex" : "none";
    badge.classList.remove("pop");
    void badge.offsetWidth; // Trigger reflow for animation
    badge.classList.add("pop");
  });
}

function showToast(message) {
  let toast = document.querySelector("#mysterioToast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "mysterioToast";
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #090e1c;
      border: 1px solid rgba(59, 130, 246, 0.4);
      color: #ffffff;
      font-family: 'Montserrat', sans-serif;
      font-size: 12.5px;
      font-weight: 700;
      padding: 10px 18px;
      border-radius: 6px;
      box-shadow: 0 12px 32px rgba(0, 0, 0, 0.85);
      z-index: 99999;
      transform: translateY(20px);
      opacity: 0;
      transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.2s ease;
      pointer-events: none;
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    document.body.appendChild(toast);
  }
  toast.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> ${message}`;
  toast.style.opacity = "1";
  toast.style.transform = "translateY(0)";

  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(20px)";
  }, 2200);
}

function copyToClipboard(text, btnElement, successMsg) {
  if (!text) return;
  const val = String(text).trim();

  function onDone() {
    if (btnElement) {
      const orig = btnElement.innerHTML;
      btnElement.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#22c55e" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> <span style="color:#22c55e; font-weight:700;">Copied!</span>`;
      setTimeout(() => { btnElement.innerHTML = orig; }, 2000);
    }
    showToast(successMsg || "Copied to clipboard!");
  }

  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(val).then(onDone).catch(() => {
      fallbackCopyExec(val, onDone);
    });
  } else {
    fallbackCopyExec(val, onDone);
  }
}

function fallbackCopyExec(text, cb) {
  const ta = document.createElement("textarea");
  ta.value = text;
  ta.style.position = "fixed";
  ta.style.top = "-9999px";
  ta.style.left = "-9999px";
  ta.style.opacity = "0";
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try {
    const ok = document.execCommand("copy");
    if (ok && cb) cb();
  } catch (e) {}
  document.body.removeChild(ta);
}

window.copyToClipboard = copyToClipboard;

function escapeHtml(str) {
  if (typeof str !== "string") return "";
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function formatAnnouncementLinks(text) {
  if (!text) return "";
  let str = String(text);
  
  if (/<a\s+/i.test(str)) {
    return str.replace(/<a\s+([^>]*)(?:target="[^"]*")?([^>]*)>/gi, '<a $1 target="_blank" rel="noopener noreferrer" $2 style="color:#1d4ed8 !important; font-weight:600 !important; text-decoration:underline !important; cursor:pointer !important;">');
  }

  str = escapeHtml(str).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (match, linkText, url) => {
    return `<a href="${url}" target="_blank" rel="noopener noreferrer" style="color:#1d4ed8 !important; font-weight:600 !important; text-decoration:underline !important; cursor:pointer !important;">${linkText}</a>`;
  });

  str = str.replace(/(?:https?:\/\/|t\.me\/)[^\s<]+/g, (url) => {
    const fullUrl = url.startsWith("t.me/") ? `https://${url}` : url;
    return `<a href="${fullUrl}" target="_blank" rel="noopener noreferrer" style="color:#1d4ed8 !important; font-weight:600 !important; text-decoration:underline !important; cursor:pointer !important;">${url}</a>`;
  });

  return str;
}

async function loadGlobalAnnouncements() {
  try {
    const res = await fetch("/api/announcements");
    if (!res.ok) return;
    const data = await res.json();
    const activeAnns = Array.isArray(data.announcements) ? data.announcements : [];

    let bar = document.querySelector("#siteAnnouncementBar");
    
    if (activeAnns.length === 0) {
      if (bar) bar.style.display = "none";
      return;
    }

    if (!bar) {
      bar = document.createElement("div");
      bar.id = "siteAnnouncementBar";
      bar.className = "site-announcement-bar";
      document.body.prepend(bar);
    }

    const itemsHtml = activeAnns.map(ann => {
      const titleStr = ann.title ? `<span style="font-weight:600; margin-right:6px;">${formatAnnouncementLinks(ann.title)}</span>` : "";
      const bodyStr = formatAnnouncementLinks(ann.content || "");
      return `<div class="announcement-item" style="display:inline-block;">${titleStr}${bodyStr}</div>`;
    }).join(`<span class="announcement-sep" style="margin: 0 16px; opacity: 0.5;">•</span>`);

    bar.innerHTML = `<div class="site-announcement-content">${itemsHtml}</div>`;
    bar.style.display = "block";
  } catch (e) {
    console.error("Failed to load announcements:", e);
  }
}

async function initGlobalAccountHeader() {
  loadGlobalAnnouncements();
  const navUserBtn = document.querySelector("#navUserBtn");
  const navUserText = document.querySelector("#navUserText");
  if (!navUserBtn) return;

  try {
    const res = await fetch("/api/auth/me");
    const data = await res.json();
    if (data && data.authenticated) {
      const displayName = (data.name && data.name.trim()) ? data.name.trim() : data.email.split("@")[0];
      const balanceStr = `£${Number(data.balance || 0).toFixed(2)}`;
      if (navUserText) {
        navUserText.textContent = `${displayName} [${balanceStr}]`;
      }

      navUserBtn.removeAttribute("href");
      navUserBtn.style.cursor = "pointer";

      let parentWrap = navUserBtn.closest(".nav-account-dropdown-wrap");
      if (!parentWrap) {
        parentWrap = document.createElement("div");
        parentWrap.className = "nav-account-dropdown-wrap";
        navUserBtn.parentNode.insertBefore(parentWrap, navUserBtn);
        parentWrap.appendChild(navUserBtn);
      }

      let dropdown = document.querySelector("#accountDropdownCard");
      if (!dropdown) {
        dropdown = document.createElement("div");
        dropdown.id = "accountDropdownCard";
        dropdown.className = "account-dropdown-card";
        parentWrap.appendChild(dropdown);
      }

      const isStaffOrAdmin = data.role === "ADMIN" || data.role === "GOD" || data.role === "STAFF";

      dropdown.innerHTML = `
        <div class="account-dropdown-header">
          <span class="account-dropdown-title">Account</span>
          <button type="button" class="account-dropdown-close" id="closeAccountDropdown" aria-label="Close">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div class="account-user-info">
          <div class="account-user-email">${(data.name && data.name.trim()) ? escapeHtml(data.name.trim()) + '<br><span style="font-size:11px; opacity:0.6;">' + escapeHtml(data.email) + '</span>' : escapeHtml(data.email)}</div>
          <div class="account-user-balance">[${balanceStr}]</div>
        </div>
        <div class="account-dropdown-actions">
          ${isStaffOrAdmin ? `
            <a href="/admin.html" class="account-dropdown-btn secondary">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
              Dashboard
            </a>
          ` : `
            <a href="/dashboard.html" class="account-dropdown-btn secondary">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
              Dashboard
            </a>
          `}
          <a href="/orders.html" class="account-dropdown-btn secondary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            Orders
          </a>
          <a href="/support.html" class="account-dropdown-btn secondary">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            Support
          </a>
          <button type="button" class="account-dropdown-btn danger" id="accountDropdownLogoutBtn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            Log out
          </button>
        </div>
      `;

      navUserBtn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        dropdown.classList.toggle("active");
      };

      const closeBtn = dropdown.querySelector("#closeAccountDropdown");
      if (closeBtn) {
        closeBtn.onclick = (e) => {
          e.stopPropagation();
          dropdown.classList.remove("active");
        };
      }

      const logoutBtn = dropdown.querySelector("#accountDropdownLogoutBtn");
      if (logoutBtn) {
        logoutBtn.onclick = async (e) => {
          e.stopPropagation();
          logoutBtn.disabled = true;
          try {
            await fetch("/api/auth/logout", { method: "POST" });
            window.location.href = "/";
          } catch (err) {
            window.location.reload();
          }
        };
      }

      document.addEventListener("click", (e) => {
        if (!parentWrap.contains(e.target)) {
          dropdown.classList.remove("active");
        }
      });
    }
  } catch (e) {
    // Guest
  }
}

// =========================================================
// EMBEDDED CRYPTO PAYMENT DRAWER MODAL
// =========================================================
let cryptoTimerInterval = null;
let cryptoPollInterval = null;

function openCryptoPaymentDrawer(data) {
  if (!data) return;
  const {
    payment_id,
    pay_address,
    pay_amount,
    pay_currency,
    coin,
    network,
    price_amount,
    expiration_seconds
  } = data;

  const coinUpper = String(coin || pay_currency || "BTC").toUpperCase();
  const netStr = network ? `${coinUpper} • ${network.toUpperCase()}` : `${coinUpper}`;
  const cryptoCode = String(pay_currency || coinUpper).toUpperCase();
  
  const coinKey = String(coin || pay_currency || "btc").toLowerCase();
  const coinImgHtml = `<img src="/icons/${coinKey.includes('usdt') ? 'usdt' : (coinKey.includes('usdc') ? 'usdc' : coinKey)}.svg" alt="${escapeHtml(coinUpper)}" width="36" height="36" class="payment-method-coin-img">`;

  // Clean old overlay if present
  let overlay = document.querySelector("#cryptoPaymentModalOverlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "cryptoPaymentModalOverlay";
    overlay.className = "modal-overlay";
    document.body.appendChild(overlay);
  }

  let remainingSecs = Number(expiration_seconds || 1200);

  function formatTime(s) {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  }

  const qrAmountUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(pay_currency + ':' + pay_address + '?amount=' + pay_amount)}`;
  const qrAddressUrl = `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(pay_address)}`;

  overlay.innerHTML = `
    <div class="crypto-invoice-card">
      <div class="crypto-invoice-header">
        <div class="crypto-invoice-coin-icon" style="background: transparent; display: flex; align-items: center; justify-content: center;">${coinImgHtml}</div>
        <div class="crypto-invoice-head-info">
          <div class="crypto-invoice-title">Pay with ${escapeHtml(coinUpper)}</div>
          <div class="crypto-invoice-subtitle">Send the exact amount. We detect it automatically on this payment address.</div>
        </div>
        <div class="crypto-invoice-timer" id="cryptoTimerLabel">${formatTime(remainingSecs)}</div>
      </div>

      <div class="crypto-invoice-status-bar">
        <span class="crypto-status-pulse-dot"></span>
        <span id="cryptoStatusText">Waiting for payment</span>
      </div>

      <div class="crypto-tab-switch-group">
        <button type="button" class="crypto-tab-btn active" id="cryptoTabWithAmount">With amount</button>
        <button type="button" class="crypto-tab-btn" id="cryptoTabWithoutAmount">Without amount</button>
      </div>

      <div class="crypto-qr-container">
        <img id="cryptoQrImg" src="${qrAmountUrl}" alt="Crypto QR Code" class="crypto-qr-img">
      </div>

      <div class="crypto-field-box">
        <div class="crypto-field-label">Amount to Send</div>
        <div class="crypto-field-row">
          <div class="crypto-field-value">${escapeHtml(String(pay_amount))} <span style="font-size:12px; color:rgba(255,255,255,0.6);">${cryptoCode}</span></div>
          <button type="button" class="crypto-copy-btn" id="cryptoCopyAmountBtn">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            Copy
          </button>
        </div>
      </div>

      <div class="crypto-meta-info-grid">
        <div class="crypto-field-box">
          <div class="crypto-field-label">Network</div>
          <div style="font-size:13px; font-weight:700; color:#fff;">${escapeHtml(netStr)}</div>
        </div>
        <div class="crypto-field-box">
          <div class="crypto-field-label">Typical Speed</div>
          <div style="font-size:13px; font-weight:700; color:#fff;">~5-15 min</div>
        </div>
      </div>

      <div class="crypto-warning-box">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="flex-shrink:0; margin-top:1px;"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <span>Send the requested amount <strong>${escapeHtml(String(pay_amount))} ${cryptoCode}</strong>. Payments of a different amount remain associated with this invoice and may need manual review.</span>
      </div>

      <div class="crypto-field-box">
        <div class="crypto-field-label">Wallet Address</div>
        <div class="crypto-field-row">
          <div class="crypto-field-value" style="font-size:12.5px; font-family:'JetBrains Mono', monospace;">${escapeHtml(pay_address)}</div>
          <button type="button" class="crypto-copy-btn" id="cryptoCopyAddressBtn">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            Copy
          </button>
        </div>
      </div>
    </div>
  `;

  overlay.classList.add("active");

  // QR Toggle Listeners
  const qrImg = overlay.querySelector("#cryptoQrImg");
  const btnWith = overlay.querySelector("#cryptoTabWithAmount");
  const btnWithout = overlay.querySelector("#cryptoTabWithoutAmount");

  if (btnWith && btnWithout && qrImg) {
    btnWith.addEventListener("click", () => {
      btnWith.classList.add("active");
      btnWithout.classList.remove("active");
      qrImg.src = qrAmountUrl;
    });

    btnWithout.addEventListener("click", () => {
      btnWithout.classList.add("active");
      btnWith.classList.remove("active");
      qrImg.src = qrAddressUrl;
    });
  }

  // Copy Buttons
  const copyAmtBtn = overlay.querySelector("#cryptoCopyAmountBtn");
  if (copyAmtBtn) {
    copyAmtBtn.addEventListener("click", () => {
      copyToClipboard(String(pay_amount), copyAmtBtn, "Crypto amount copied to clipboard!");
    });
  }

  const copyAddrBtn = overlay.querySelector("#cryptoCopyAddressBtn");
  if (copyAddrBtn) {
    copyAddrBtn.addEventListener("click", () => {
      copyToClipboard(pay_address, copyAddrBtn, "Wallet address copied to clipboard!");
    });
  }

  // Countdown timer
  if (cryptoTimerInterval) clearInterval(cryptoTimerInterval);
  const timerLabel = overlay.querySelector("#cryptoTimerLabel");
  cryptoTimerInterval = setInterval(() => {
    remainingSecs--;
    if (timerLabel) timerLabel.textContent = formatTime(Math.max(0, remainingSecs));
    if (remainingSecs <= 0) {
      clearInterval(cryptoTimerInterval);
      const statusText = overlay.querySelector("#cryptoStatusText");
      if (statusText) statusText.textContent = "Invoice Expired";
    }
  }, 1000);

  // Status Polling Interval (every 4s)
  if (cryptoPollInterval) clearInterval(cryptoPollInterval);
  cryptoPollInterval = setInterval(async () => {
    try {
      const res = await fetch(`/api/nowpayments/status/${encodeURIComponent(payment_id)}`);
      const stData = await res.json();
      if (res.ok && stData.isPaid) {
        clearInterval(cryptoPollInterval);
        clearInterval(cryptoTimerInterval);
        const statusText = overlay.querySelector("#cryptoStatusText");
        if (statusText) statusText.textContent = "Payment Received! Processing...";
        if (typeof window.showToast === "function") window.showToast("Payment received successfully!");
        
        setTimeout(() => {
          overlay.classList.remove("active");
          if (stData.type === "topup") {
            window.location.href = "/dashboard.html";
          } else {
            window.location.href = stData.orderId ? `/orders.html?orderId=${stData.orderId}` : "/orders.html";
          }
        }, 1500);
      }
    } catch (e) {
      // Polling retry
    }
  }, 4000);

  // Close when clicking outside card
  overlay.onclick = (e) => {
    if (e.target === overlay) {
      overlay.classList.remove("active");
      if (cryptoTimerInterval) clearInterval(cryptoTimerInterval);
      if (cryptoPollInterval) clearInterval(cryptoPollInterval);
    }
  };
}

function showMysterioAlert(opts) {
  let overlay = document.querySelector("#mysterioAlertModalOverlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "mysterioAlertModalOverlay";
    overlay.className = "mysterio-alert-modal-overlay";
    overlay.innerHTML = `
      <div class="mysterio-alert-modal-card">
        <div class="mysterio-alert-head">
          <div class="mysterio-alert-title-wrap">
            <div class="mysterio-alert-title" id="mysterioAlertTitle">Notice</div>
            <div class="mysterio-alert-subtitle" id="mysterioAlertSubtitle">Mysterio Store</div>
          </div>
        </div>
        <div class="mysterio-alert-body" id="mysterioAlertBody"></div>
        <button type="button" class="mysterio-alert-btn" id="mysterioAlertBtn">Got it</button>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  const titleEl = overlay.querySelector("#mysterioAlertTitle");
  const subEl = overlay.querySelector("#mysterioAlertSubtitle");
  const bodyEl = overlay.querySelector("#mysterioAlertBody");
  const btnEl = overlay.querySelector("#mysterioAlertBtn");

  if (typeof opts === "string") {
    opts = { message: opts };
  }

  titleEl.textContent = opts.title || (opts.isMinimalError ? "Minimum Amount Required" : "Notice");
  subEl.textContent = opts.subtitle || (opts.isMinimalError ? "NOWPayments Requirement" : "Mysterio Store");

  if (opts.isMinimalError && (opts.gbpMin || opts.usdMin)) {
    const minVal = Number(opts.gbpMin || opts.usdMin || 0);
    const currVal = Number(opts.currentAmountGbp || opts.currentAmountUsd || 0);
    const diff = Math.max(0, minVal - currVal);
    bodyEl.innerHTML = `
      <div class="mysterio-alert-msg">${opts.error || opts.message || ''}</div>
      <div class="mysterio-alert-grid">
        <div class="mysterio-alert-row">
          <span class="mysterio-alert-label">Selected Coin</span>
          <span class="mysterio-alert-val">${opts.coinSymbol || 'Crypto'}</span>
        </div>
        <div class="mysterio-alert-row">
          <span class="mysterio-alert-label">Minimum Required</span>
          <span class="mysterio-alert-val" style="color: #60a5fa; font-weight: 800;">£${minVal.toFixed(2)} GBP <span style="font-size:11px; opacity:0.65; font-weight:500;">(${opts.cryptoMin || ''} ${opts.coinSymbol || ''})</span></span>
        </div>
        <div class="mysterio-alert-row">
          <span class="mysterio-alert-label">Current Total</span>
          <span class="mysterio-alert-val">£${currVal.toFixed(2)} GBP</span>
        </div>
        ${diff > 0 ? `
        <div class="mysterio-alert-row">
          <span class="mysterio-alert-label">Amount Needed</span>
          <span class="mysterio-alert-val" style="color: #fbbf24; font-weight: 800;">+£${diff.toFixed(2)} GBP</span>
        </div>
        ` : ''}
      </div>
      <div class="mysterio-alert-tip">
        <strong>Recommendation:</strong> Add items to reach <strong>£${minVal.toFixed(2)} GBP</strong>, or select <strong>LTC/SOL</strong> for smaller order amounts.
      </div>
    `;
  } else {
    bodyEl.innerHTML = `<div class="mysterio-alert-msg">${opts.error || opts.message || opts.text || "An issue occurred."}</div>`;
  }

  overlay.classList.add("active");

  btnEl.onclick = function() {
    overlay.classList.remove("active");
  };
  overlay.onclick = function(e) {
    if (e.target === overlay) overlay.classList.remove("active");
  };
}

window.addToCartStorage = addToCartStorage;
window.updateCartBadge = updateCartBadge;
window.showToast = showToast;
window.getCart = getCart;
window.setCart = setCart;
window.initGlobalAccountHeader = initGlobalAccountHeader;
window.openCryptoPaymentDrawer = openCryptoPaymentDrawer;
window.showMysterioAlert = showMysterioAlert;

document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();
  initGlobalAccountHeader();
});
