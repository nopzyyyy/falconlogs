const grid = document.querySelector("#productGrid");
const search = document.querySelector("#productSearch");
const countNum = document.querySelector("#productCountNum");
const categoryDropdownToggle = document.querySelector("#categoryDropdownToggle");
const categoryMenuPanel = document.querySelector("#categoryMenuPanel");
const selectedCategoryLabel = document.querySelector("#selectedCategoryLabel");

let products = [];
let categories = [];
let activeCategory = "All";

let selectedProduct = null;
let selectedVariant = null;
let selectedQty = 1;

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

function formatVariantName(name) {
  if (!name) return "";
  let varName = String(name).trim();
  varName = varName.replace(/(\d+(?:\.\d+)?)\s*\$/g, "£$1")
                   .replace(/\$\s*(\d+(?:\.\d+)?)/g, "£$1")
                   .replace(/(\d+(?:\.\d+)?)\s*£/g, "£$1");
  return varName;
}

// Check logged in user status
async function checkAuthStatus() {
  if (typeof initGlobalAccountHeader === "function") {
    await initGlobalAccountHeader();
  }
}

// Category Dropdown Toggle (Collapsed by Default)
if (categoryDropdownToggle && categoryMenuPanel) {
  categoryDropdownToggle.addEventListener("click", (e) => {
    e.stopPropagation();
    const isCurrentlyOpen = categoryMenuPanel.style.display === "flex";
    categoryMenuPanel.style.display = isCurrentlyOpen ? "none" : "flex";
    categoryDropdownToggle.classList.toggle("open", !isCurrentlyOpen);
  });

  // Close dropdown when clicking outside
  document.addEventListener("click", (e) => {
    if (!categoryDropdownToggle.contains(e.target) && !categoryMenuPanel.contains(e.target)) {
      categoryMenuPanel.style.display = "none";
      categoryDropdownToggle.classList.remove("open");
    }
  });
}

const ICON_MAP = {
  restaurant: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m16 2-3.4 3.4a2.5 2.5 0 0 0 0 3.5l2.5 2.5a2.5 2.5 0 0 0 3.5 0L22 8Z"/><path d="m15 5 5 5"/><path d="m8.5 8.5 6 6"/><path d="m2 22 7.5-7.5"/></svg>`,
  hotel: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2Z"/><path d="M9 16h6"/><path d="M9 12h6"/><path d="M9 8h6"/></svg>`,
  flight: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.7 5.3c.3.4.8.5 1.3.3l.5-.3c.4-.2.6-.6.5-1.1Z"/></svg>`,
  card_giftcard: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="14" x="3" y="8" rx="2"/><path d="M12 5a3 3 0 1 0-3 3h6a3 3 0 1 0-3-3Z"/><path d="M12 8v14"/><path d="M3 13h18"/></svg>`,
  shopping_bag: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>`,
  shopping_cart: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>`,
  beach_access: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M4.93 4.93 19.07 19.07"/><path d="M4.93 19.07 19.07 4.93"/></svg>`,
  confirmation_number: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/><path d="M13 5v14"/><path d="M9 5v14"/></svg>`,
  local_gas_station: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18"/><path d="M15 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2V9.83a2 2 0 0 0-.59-1.42L20.41 6.41a2 2 0 0 0-1.41-.59H17"/><path d="M7 11h4"/><rect width="8" height="5" x="5" y="4" rx="1"/></svg>`,
  checkroom: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 10a2 2 0 1 0-2-2 2.5 2.5 0 0 1 2.5 2.5V11"/><path d="M2 17.5 10.6 13a2.4 2.4 0 0 1 2.8 0L22 17.5a1 1 0 0 1-.5 1.8H2.5a1 1 0 0 1-.5-1.8Z"/></svg>`,
  home: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
  play_circle_outline: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>`,
  movie: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="2.18" ry="2.18"/><line x1="7" y1="2" x2="7" y2="22"/><line x1="17" y1="2" x2="17" y2="22"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="2" y1="7" x2="7" y2="7"/><line x1="2" y1="17" x2="7" y2="17"/><line x1="17" y1="17" x2="22" y2="17"/><line x1="17" y1="7" x2="22" y2="7"/></svg>`,
  directions_car: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 12 10s-6.7.6-8.5 1.1C2.7 11.3 2 12.1 2 13v3c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/><path d="M5 10l2-5h10l2 5"/></svg>`,
  workspace_premium: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>`,
  mail: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>`,
  grid_view: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>`,
  folder: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/></svg>`,
  star: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  settings: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.38a2 2 0 0 0-.73-2.73l-.15-.09a2 2 0 0 1-1-1.74v-.51a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>`,
  person: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  vpn_key: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21 2-2 2m-1.5 1.5L16 4l-4 4m6-2-4 4"/><circle cx="7.5" cy="16.5" r="4.5"/></svg>`,
  credit_card: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>`,
  shield: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  build: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
  cloud: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></svg>`,
  dns: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2"/><rect width="20" height="8" x="2" y="14" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`,
  security: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  notifications: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>`,
  chat: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>`,
  terminal: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>`,
  headset_mic: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/></svg>`,
  lock: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  help_outline: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`
};

function getCategoryIconHtml(icon) {
  const defaultSvg = `<svg class="category-dropdown-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:16px;height:16px;color:var(--accent-light,#60a5fa);flex-shrink:0;"><rect width="7" height="7" x="3" y="3" rx="1"></rect><rect width="7" height="7" x="14" y="3" rx="1"></rect><rect width="7" height="7" x="14" y="14" rx="1"></rect><rect width="7" height="7" x="3" y="14" rx="1"></rect></svg>`;
  
  if (!icon || icon === "grid" || icon === "grid_view") {
    return defaultSvg;
  }
  if (ICON_MAP[icon]) {
    return `<span style="display:inline-flex;align-items:center;width:16px;height:16px;color:var(--accent-light,#60a5fa);flex-shrink:0;">${ICON_MAP[icon]}</span>`;
  }
  if (typeof icon === "string" && icon.startsWith("<svg")) {
    return `<span style="display:inline-flex;align-items:center;width:16px;height:16px;color:var(--accent-light,#60a5fa);flex-shrink:0;">${icon}</span>`;
  }
  if (typeof icon === "string" && (icon.startsWith("http://") || icon.startsWith("https://") || icon.startsWith("/"))) {
    return `<img src="${escapeHtml(icon)}" alt="" style="width:16px;height:16px;object-fit:contain;flex-shrink:0;">`;
  }
  return defaultSvg;
}

function renderCategoryMenu() {
  if (!categoryMenuPanel) return;

  const normalizedCats = categories.map(c => typeof c === "string" ? { name: c, icon: "grid" } : c);

  categoryMenuPanel.innerHTML = `
    <button type="button" class="category-item-btn ${activeCategory === "All" ? "active" : ""}" data-category="All" style="display:flex;align-items:center;gap:8px;">
      ${getCategoryIconHtml("grid")}
      <span>All</span>
    </button>
    ${normalizedCats.map(c => `
      <button type="button" class="category-item-btn ${activeCategory === c.name ? "active" : ""}" data-category="${escapeHtml(c.name)}" style="display:flex;align-items:center;gap:8px;">
        ${getCategoryIconHtml(c.icon)}
        <span>${escapeHtml(c.name)}</span>
      </button>
    `).join("")}
  `;

  // Update selected category dropdown toggle button icon + text label
  const matchedCat = normalizedCats.find(c => c.name === activeCategory);
  const leftWrap = categoryDropdownToggle ? categoryDropdownToggle.querySelector(".category-dropdown-left") : null;
  if (leftWrap) {
    const iconHtml = matchedCat ? getCategoryIconHtml(matchedCat.icon) : getCategoryIconHtml("grid");
    const labelText = activeCategory === "All" ? "Search Category" : activeCategory;
    leftWrap.innerHTML = `
      ${iconHtml}
      <span id="selectedCategoryLabel">${escapeHtml(labelText)}</span>
    `;
  }

  categoryMenuPanel.querySelectorAll(".category-item-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      activeCategory = btn.dataset.category;
      if (categoryMenuPanel) categoryMenuPanel.style.display = "none";
      if (categoryDropdownToggle) categoryDropdownToggle.classList.remove("open");
      renderCategoryMenu();
      renderProducts();
    });
  });
}

function getProductStock(product) {
  if (!Array.isArray(product.variants) || product.variants.length === 0) {
    return 0;
  }
  return product.variants.reduce((sum, v) => {
    if (v.unlimitedStock) return sum + 999999;
    const count = Array.isArray(v.stock) ? v.stock.filter(s => !s.isSold).length : 0;
    return sum + count;
  }, 0);
}

function renderProducts() {
  if (!grid) return;
  const query = search ? search.value.trim().toLowerCase() : "";
  const filtered = products.filter(product => {
    const matchesCategory = activeCategory === "All" || product.category === activeCategory;
    const matchesSearch = (product.title || "").toLowerCase().includes(query) || (product.category || "").toLowerCase().includes(query) || (product.tags || "").toLowerCase().includes(query);
    return matchesCategory && matchesSearch && !product.isHidden;
  });

  if (countNum) {
    countNum.textContent = filtered.length;
  }

  if (filtered.length === 0) {
    grid.innerHTML = `<div style="grid-column: 1/-1; text-align:center; padding: 40px; color: var(--muted); font-weight:600;">No products found matching your search.</div>`;
    return;
  }

  grid.innerHTML = filtered.map(product => {
    const hasVariants = Array.isArray(product.variants) && product.variants.length > 0;
    const minPrice = hasVariants
      ? Math.min(...product.variants.map(v => Number(v.price) || 0))
      : 0;
    const totalStock = getProductStock(product);
    const inStock = totalStock > 0;

    return `
      <article class="product-card ${!inStock ? 'product-out-of-stock' : ''}">
        <div class="product-card-img-wrap" data-card-product-id="${escapeHtml(product.id)}">
          ${product.image 
            ? `<img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.title)}" class="product-card-img">`
            : `<div class="product-card-placeholder">${escapeHtml(product.title.slice(0, 2).toUpperCase())}</div>`
          }
        </div>
        <div class="product-card-body">
          <h3 class="product-card-title">${escapeHtml(product.title)}</h3>
          <span class="product-card-stock" style="color: ${inStock ? '#60a5fa' : '#f87171'};">
            ${inStock ? `${totalStock >= 9999 ? 'In Stock' : `${totalStock} In Stock`}` : 'Out of Stock'}
          </span>
          <button type="button" class="product-card-btn ${!inStock ? 'disabled-btn' : ''}" data-product-id="${escapeHtml(product.id)}">
            ${inStock ? `Purchase | £${minPrice.toFixed(2)}` : 'Out of Stock'}
          </button>
        </div>
      </article>
    `;
  }).join("");

  // Attach card click handlers to open modal
  grid.querySelectorAll("[data-product-id], [data-card-product-id]").forEach(el => {
    el.addEventListener("click", () => {
      const pid = el.dataset.productId || el.dataset.cardProductId;
      const product = products.find(p => p.id === pid);
      if (product) openPurchaseModal(product);
    });
  });
}

// Purchase Modal Elements
const modalOverlay = document.querySelector("#purchaseModalOverlay");
const closeModalBtn = document.querySelector("#closePurchaseModal");
const modalTitle = document.querySelector("#purchaseModalTitle");
const modalWarranty = document.querySelector("#purchaseModalWarranty");
const modalTags = document.querySelector("#purchaseModalTags");
const variantSelect = document.querySelector("#purchaseModalVariantSelect");
const qtyMinus = document.querySelector("#purchaseQtyMinus");
const qtyPlus = document.querySelector("#purchaseQtyPlus");
const qtyVal = document.querySelector("#purchaseQtyVal");
const modalTotal = document.querySelector("#purchaseModalTotal");
const buyNowBtn = document.querySelector("#purchaseBuyNowBtn");
const addToCartBtn = document.querySelector("#purchaseAddToCartBtn");
const customInputsDiv = document.querySelector("#purchaseModalCustomInputs");
const modalFormView = document.querySelector("#purchaseModalFormView");
const modalAddedView = document.querySelector("#purchaseModalAddedView");
const modalAddedSummary = document.querySelector("#purchaseModalAddedSummary");
const keepShoppingBtn = document.querySelector("#purchaseKeepShoppingBtn");

function openPurchaseModal(product) {
  selectedProduct = product;
  selectedQty = 1;
  if (qtyVal) qtyVal.textContent = selectedQty;

  if (modalTitle) modalTitle.textContent = product.title;
  if (modalWarranty) {
    modalWarranty.textContent = product.warranty || "24 Hours Warranty!";
  }

  // Reset to form view
  if (modalFormView) modalFormView.style.display = "flex";
  if (modalAddedView) modalAddedView.style.display = "none";

  // Tags
  if (modalTags) {
    const rawTags = (product.tags || product.category || "").split(",").map(t => t.trim()).filter(Boolean);
    modalTags.innerHTML = rawTags.map(t => `<span class="modal-tag-pill">${escapeHtml(t)}</span>`).join("");
  }

  // Variants & Live Stock Sync
  if (variantSelect) {
    const variants = Array.isArray(product.variants) ? product.variants : [];

    if (variants.length === 0) {
      variantSelect.innerHTML = `<option value="" disabled selected>No variants available</option>`;
      selectedVariant = null;
      if (modalTotal) modalTotal.textContent = "£0.00";
      if (buyNowBtn) { buyNowBtn.disabled = true; buyNowBtn.style.opacity = "0.4"; buyNowBtn.style.pointerEvents = "none"; buyNowBtn.textContent = "Out of Stock"; }
      if (addToCartBtn) { addToCartBtn.disabled = true; addToCartBtn.style.opacity = "0.4"; addToCartBtn.style.pointerEvents = "none"; addToCartBtn.textContent = "Out of Stock"; }
    } else {
      variantSelect.innerHTML = variants.map(v => {
        const vStock = v.unlimitedStock ? 999999 : (Array.isArray(v.stock) ? v.stock.filter(s => !s.isSold).length : 0);
        const isOut = vStock === 0;
        return `
          <option value="${escapeHtml(v.id)}" data-price="${v.price}" data-stock="${vStock}" ${isOut ? 'disabled' : ''}>
            ${escapeHtml(v.name)} - £${Number(v.price).toFixed(2)} (${isOut ? 'Out of Stock' : (vStock >= 9999 ? 'In Stock' : `${vStock} in stock`)})
          </option>
        `;
      }).join("");

      selectedVariant = variants.find(v => {
        const s = v.unlimitedStock ? 999999 : (Array.isArray(v.stock) ? v.stock.filter(st => !st.isSold).length : 0);
        return s > 0;
      }) || variants[0];

      variantSelect.value = selectedVariant.id;

      const currentStock = selectedVariant.unlimitedStock ? 999999 : (Array.isArray(selectedVariant.stock) ? selectedVariant.stock.filter(s => !s.isSold).length : 0);
      const isAvailable = currentStock > 0;

      if (buyNowBtn) {
        buyNowBtn.disabled = !isAvailable;
        buyNowBtn.style.opacity = isAvailable ? "1" : "0.4";
        buyNowBtn.style.pointerEvents = isAvailable ? "auto" : "none";
        buyNowBtn.textContent = isAvailable ? "Buy Now" : "Out of Stock";
      }
      if (addToCartBtn) {
        addToCartBtn.disabled = !isAvailable;
        addToCartBtn.style.opacity = isAvailable ? "1" : "0.4";
        addToCartBtn.style.pointerEvents = isAvailable ? "auto" : "none";
        addToCartBtn.textContent = isAvailable ? "Add to Cart" : "Out of Stock";
      }

      variantSelect.onchange = () => {
        selectedVariant = variants.find(v => v.id === variantSelect.value) || variants[0];
        const vStock = selectedVariant.unlimitedStock ? 999999 : (Array.isArray(selectedVariant.stock) ? selectedVariant.stock.filter(s => !s.isSold).length : 0);
        const hasStock = vStock > 0;
        if (buyNowBtn) {
          buyNowBtn.disabled = !hasStock;
          buyNowBtn.style.opacity = hasStock ? "1" : "0.4";
          buyNowBtn.style.pointerEvents = hasStock ? "auto" : "none";
          buyNowBtn.textContent = hasStock ? "Buy Now" : "Out of Stock";
        }
        if (addToCartBtn) {
          addToCartBtn.disabled = !hasStock;
          addToCartBtn.style.opacity = hasStock ? "1" : "0.4";
          addToCartBtn.style.pointerEvents = hasStock ? "auto" : "none";
          addToCartBtn.textContent = hasStock ? "Add to Cart" : "Out of Stock";
        }
        updateModalTotal();
      };
    }
  }

  // Custom Inputs (e.g., custom email/password requirement)
  if (customInputsDiv) {
    let customHtml = "";
    if (product.askEmail) {
      customHtml += `<div class="modal-form-group"><label class="modal-label">Your Email for Delivery</label><input type="email" id="customInputEmail" class="auth-input" placeholder="email@domain.com" required></div>`;
    }
    if (product.askPassword) {
      customHtml += `<div class="modal-form-group"><label class="modal-label">Account Password</label><input type="text" id="customInputPassword" class="auth-input" placeholder="Desired password"></div>`;
    }
    if (product.askDescription) {
      customHtml += `<div class="modal-form-group"><label class="modal-label">Custom Notes / ID</label><input type="text" id="customInputNotes" class="auth-input" placeholder="Additional details"></div>`;
    }
    customInputsDiv.innerHTML = customHtml;
    customInputsDiv.style.display = customHtml ? "flex" : "none";
  }

  updateModalTotal();
  if (modalOverlay) modalOverlay.classList.add("active");
}

function updateModalTotal() {
  if (!selectedVariant || !modalTotal) return;
  const total = Number(selectedVariant.price || 0) * selectedQty;
  modalTotal.textContent = `£${total.toFixed(2)}`;
}

// Stepper
if (qtyMinus && qtyPlus && qtyVal) {
  qtyMinus.addEventListener("click", () => {
    if (selectedQty > 1) {
      selectedQty--;
      qtyVal.textContent = selectedQty;
      updateModalTotal();
    }
  });
  qtyPlus.addEventListener("click", () => {
    selectedQty++;
    qtyVal.textContent = selectedQty;
    updateModalTotal();
  });
}

// Close modal
if (closeModalBtn && modalOverlay) {
  closeModalBtn.addEventListener("click", () => modalOverlay.classList.remove("active"));
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) modalOverlay.classList.remove("active");
  });
}

if (keepShoppingBtn && modalOverlay) {
  keepShoppingBtn.addEventListener("click", () => modalOverlay.classList.remove("active"));
}

// Add To Cart Helper
function addCurrentToCart() {
  if (!selectedProduct || !selectedVariant) return false;
  
  let customData = {};
  const emailInput = document.querySelector("#customInputEmail");
  const passInput = document.querySelector("#customInputPassword");
  const notesInput = document.querySelector("#customInputNotes");
  if (emailInput) customData.email = emailInput.value.trim();
  if (passInput) customData.password = passInput.value.trim();
  if (notesInput) customData.notes = notesInput.value.trim();

  const cartItem = {
    id: `${selectedProduct.id}:${selectedVariant.id}`,
    productId: selectedProduct.id,
    variantId: selectedVariant.id,
    name: selectedProduct.title,
    variantName: formatVariantName(selectedVariant.name),
    price: Number(selectedVariant.price),
    quantity: selectedQty,
    image: selectedProduct.image || "",
    customData
  };

  if (typeof window.addToCartStorage === "function") {
    window.addToCartStorage(cartItem);
  } else {
    let cart = [];
    try { cart = JSON.parse(localStorage.getItem("mysterio_cart") || "[]"); } catch (e) {}
    const existing = cart.find(c => c.productId === cartItem.productId && c.variantId === cartItem.variantId);
    if (existing) {
      existing.quantity += cartItem.quantity;
    } else {
      cart.push(cartItem);
    }
    localStorage.setItem("mysterio_cart", JSON.stringify(cart));
    if (typeof window.updateCartBadge === "function") window.updateCartBadge();
  }
  return true;
}

if (addToCartBtn) {
  addToCartBtn.addEventListener("click", () => {
    if (addCurrentToCart()) {
      if (typeof window.updateCartBadge === "function") window.updateCartBadge();
      
      // Transition modal to Added to Cart confirmation view
      if (modalFormView) modalFormView.style.display = "none";
      if (modalAddedView) modalAddedView.style.display = "flex";
    }
  });
}

if (buyNowBtn) {
  buyNowBtn.addEventListener("click", () => {
    if (addCurrentToCart()) {
      window.location.href = "/cart.html";
    }
  });
}

function showGridSkeletonLoading() {
  if (!grid) return;
  grid.innerHTML = `
    <div style="display:flex;align-items:center;justify-content:center;padding:60px 0;width:100%;">
      <div style="width:36px;height:36px;border:3px solid rgba(255,255,255,0.1);border-top-color:#2563eb;border-radius:50%;animation:spinLoader .6s linear infinite;"></div>
    </div>
    <style>@keyframes spinLoader{to{transform:rotate(360deg)}}</style>
  `;
}

// Initial Data Fetch
async function initStore() {
  checkAuthStatus();
  showGridSkeletonLoading();
  try {
    const [prodRes, catRes] = await Promise.all([
      fetch("/api/products"),
      fetch("/api/categories")
    ]);
    const prodData = await prodRes.json();
    const catData = await catRes.json();
    products = Array.isArray(prodData) ? prodData : (prodData.products || []);
    categories = Array.isArray(catData) ? catData : (catData.categories || []);
    renderCategoryMenu();
    renderProducts();
  } catch (e) {
    console.error("Error loading products:", e);
  }
}

if (search) {
  search.addEventListener("input", renderProducts);
}

document.addEventListener("DOMContentLoaded", () => {
  initStore();
  if (typeof window.updateCartBadge === "function") window.updateCartBadge();
});
